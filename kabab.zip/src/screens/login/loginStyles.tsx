import { StyleSheet } from "react-native";

export const loginStyles = StyleSheet.create({
    container: {
      flex: .5,
      backgroundColor: '#af1',
      alignItems: 'center',
      justifyContent: 'center',
    },
});