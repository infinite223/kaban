<h1>
  Elo Elo
  <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="30px"/>
</h1>

jak odpalić projekt?
- pobrać i zainstalować noda by korzystać z npm-a itp
    https://nodejs.org/en/download/
    
- sklonować te repo do swojetgo folderu gdzieś na PC
- wejść w CMD do katalogu z projektem
- wpisać npm i (aby zainstalować wszystkie niezbędne biblioteki)
- wpisać code . (żeby odpalic VS do edycji kodu)
- wpisać npm start (aby odpalić projekt)
- na telefonie pobrać ze sklepu play lub app store aplikacjie EXPO 
  https://play.google.com/store/apps/details?id=host.exp.exponent&gl=US (android)
- odpalić aplikacjie na telefonie i zeskanować kod QR z terminala / można odpalić na emulatorze android studio  

